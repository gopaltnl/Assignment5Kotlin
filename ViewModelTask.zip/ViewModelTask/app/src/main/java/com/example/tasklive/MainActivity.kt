package com.example.tasklive

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.example.tasklive.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding : ActivityMainBinding
    lateinit var newView: NewView
    var c:Int = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_main)
        newView = ViewModelProvider(this).get(NewView::class.java)
        binding.setLifecycleOwner(this)

        binding.update.setOnClickListener {
            newView.store()
            binding.display.text = newView.list.toString()

        }
        binding.next.setOnClickListener {
            if(c<=newView.list.size){
                binding.tv.text = newView.list[c]
                c++
            }

        }
        binding.prev.setOnClickListener {
            if(c<=newView.list.size){
                binding.tv.text = newView.list[c]
                c--
            }

        }
    }
}
