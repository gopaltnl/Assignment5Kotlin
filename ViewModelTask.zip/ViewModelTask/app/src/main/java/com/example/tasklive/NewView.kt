package com.example.tasklive

import androidx.lifecycle.ViewModel

class NewView : ViewModel() {

    var itemsList: MutableList<String> = mutableListOf(
        "Alpha",
        "Beta",
        "Cupcake",
        "Donut",
        "Eclairs",
        "Froyo",
        "Ginger",
        "HoneyComb",
        "IceCream",
        "JellyBean"
    )
    var list: MutableList<String> = mutableListOf()
    var c: Int = 0
    var d: Int = 0
    fun store() {
        list.add(" " + itemsList[c])
        c++
    }

}




